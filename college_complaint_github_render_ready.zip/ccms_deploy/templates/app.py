<!DOCTYPE html>
<html>
<head>
    <title>College Complaint Management</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f7fb;
        }

        header {
            background: #1e3a8a;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .container {
            text-align: center;
            padding: 70px 20px;
        }

        h1 {
            color: #1e3a8a;
            font-size: 38px;
        }

        p {
            color: #555;
            font-size: 18px;
        }

        .buttons {
            margin-top: 35px;
        }

        button {
            padding: 14px 28px;
            margin: 10px;
            border: none;
            border-radius: 8px;
            background: #1e3a8a;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #162d6b;
        }

        footer {
            margin-top: 80px;
            padding: 15px;
            background: #1e3a8a;
            color: white;
            text-align: center;
        }
    </style>
</head>

<body>

    <header>
        <h2>🏫 College Complaint Management System</h2>
    </header>

    <div class="container">

        <h1>Welcome to College Complaint Portal</h1>

        <p>
            Submit your complaints and track their status easily.
        </p>

        <div class="buttons">
            <button>Student Login</button>
            <button>Register</button>
            <button>Admin Login</button>
        </div>

    </div>

    <footer>
        © 2026 College Complaint Management System
    </footer>

</body>
</html>